/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;

/**
 *
 * @author ppolozyu
 */
public class VarV {
  
    String s;

    public VarV(String s) {
        this.s = s;
    }

    public String getVarV() {
        return s;
    }

    public void setVarV(String s) {
        this.s = s;
    }
 
    void print_value() {
        System.out.print(s);
    }   
}
