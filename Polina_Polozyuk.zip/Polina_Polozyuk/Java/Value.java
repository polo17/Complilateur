package javaapp;

abstract class Value extends Object {

    void print_value() {
	System.out.print("print_value " + this + "NOT IMPLEMENTED");
    }
}
