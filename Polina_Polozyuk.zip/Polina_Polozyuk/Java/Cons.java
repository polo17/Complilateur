/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;

/**
 *
 * @author ppolozyu
 */
public class Cons extends Instr{

    @Override
    void exec_instr(Config cf) {
      
        ValueSe y = (ValueSe)cf.get_stack().pop();
        cf.set_value(new PairV(y.get_valeur(), cf.get_value()));
        cf.get_code().pop();
    }
    
    
    
}
