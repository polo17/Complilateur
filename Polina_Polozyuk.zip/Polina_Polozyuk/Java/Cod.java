/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;

import java.util.LinkedList;

/**
 *
 * @author ppolozyu
 */
public class Cod extends StackElem{
    
    LinkedList<Instr> list;
    
        
    public Cod(LinkedList<Instr> liste){
        this.list = liste;
    }

    public LinkedList<Instr> get_code() {
        return list;
    }

    public void setElement(Instr i) {
        this.list.add(i);
    }
    
    public void getElement(int i) {
        this.list.get(i);
    }


}
