/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;
import java.util.LinkedList;
/**
 *
 * @author ppolozyu
 */
public class App extends Instr{

    @Override
    void exec_instr(Config cf) {
        
        cf.get_code().pop();
        
        
        PairV pair = (PairV)cf.get_value();
        
        
        ClosureV closure = (ClosureV) pair.fst();
    
        
        cf.set_value(new PairV(closure.get_valeur(), pair.snd()));
        
       
        cf.get_stack().addFirst(new Cod(cf.get_code()));
        

        cf.set_code(new LinkedList<>(closure.get_code()));
    }
    
}
