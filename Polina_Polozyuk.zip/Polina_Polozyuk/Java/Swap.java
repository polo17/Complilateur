/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;

/**
 *
 * @author ppolozyu
 */
public class Swap extends Instr{

    @Override
    void exec_instr(Config cf) {
        Value x = cf.get_value();

        Value y = ((ValueSe)cf.get_stack().pop()).get_valeur();

        cf.set_value(y);
        cf.get_stack().addFirst(new ValueSe(x));
        
        cf.get_code().pop();
    }
    
    
    
}
