/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;

/**
 *
 * @author ppolozyu
 */
public class Pair <f,s> {
    
    f fst;
    s snd;
    
    public Pair(f fst, s snd){
        this.fst = fst;
        this.snd = snd;
    }
    
    public f get_first(){
        return fst;
    }
    
    public s get_second(){
        return snd;
    }
    
    
}

