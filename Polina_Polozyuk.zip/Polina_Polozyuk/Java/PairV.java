/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;

/**
 *
 * @author ppolozyu
 */
class PairV extends Value {
    
    Value p1;
    Value p2;

    /* Constructors */
    public PairV (Value i, Value j) {
	p1 = i;
        p2 = j;
    }

    public Value fst () {
        return p1;
    }
    
    public Value snd () {
        return p2;
    }     
    
    void set_fst(Value i) {
        p1 = i;
    }
    void set_snd (Value i) {
        p2 = i;
    }    

    void print_value() {
        System.out.print("(");
        System.out.print(p1);
        System.out.print(",");
        System.out.print(p2);
        System.out.print(")");
    }    


}
