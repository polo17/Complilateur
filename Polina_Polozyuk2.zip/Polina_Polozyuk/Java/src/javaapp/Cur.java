/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;
import java.util.LinkedList;
/**
 *
 * @author ppolozyu
 */
public class Cur extends Instr{
   LinkedList<Instr> code;
    
    public Cur(LinkedList<Instr> code){
        this.code = code;
    }

    @Override
    void exec_instr(Config cf) {
        cf.set_value(new ClosureV(code,cf.get_value()));
        cf.get_code().pop();
    }
    
}
