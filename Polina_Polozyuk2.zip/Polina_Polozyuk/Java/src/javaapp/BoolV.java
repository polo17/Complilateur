/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;

/**
 *
 * @author ppolozyu
 */
public class BoolV extends Value {
    /* Fields */
    boolean bo;

    /* Constructors */
    public BoolV (boolean b) {
	this.bo = b;
    }    

    public boolean getBoolV() {
        return bo;
    }

    public void setBoolV(boolean bo) {
        this.bo = bo;
    }
     void print_value(){
        System.out.print(bo);
    }   
}
