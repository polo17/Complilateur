package javaapp;

class NullV extends Value {

    /* Constructors */
    public NullV () {
    }
    void print_value() {
        System.out.print("Null");
    }
}
