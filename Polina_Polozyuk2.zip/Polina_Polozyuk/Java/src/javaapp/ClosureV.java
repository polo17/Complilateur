/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;
import java.util.LinkedList;
/**
 *
 * @author ppolozyu
 */
public class ClosureV extends Value{
    
    Value p1;
    LinkedList<Instr> c1;

    /* Constructors */
    public ClosureV ( LinkedList<Instr> c,Value p) {
	p1 = p;
        c1 = c;
    }

    public Value get_valeur() {
        return p1;
    }

    public LinkedList<Instr> get_code() {
        return c1;
    }

    public void setValue(Value p1) {
        this.p1 = p1;
    }

    public void setCod(LinkedList<Instr> c1) {
        this.c1 = c1;
    }
 
    void print_value() {
        System.out.print(p1);
        System.out.print(c1);
    }   
}
