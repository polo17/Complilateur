package javaapp;

abstract class StackElem extends Object {

}
