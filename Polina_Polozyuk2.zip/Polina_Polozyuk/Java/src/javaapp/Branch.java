/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;
import java.util.LinkedList;
/**
 *
 * @author ppolozyu
 */
public class Branch extends Instr{
    private final LinkedList<Instr> cd1, cd2;
    
    public Branch(LinkedList<Instr> c1, LinkedList<Instr> c2){
        cd1 = c1;
        cd2 = c2;
    }
    
    
    @Override
    void exec_instr(Config cf) {
        cf.get_code().pop();
        
        
        Value x = ((ValueSe)cf.get_stack().pop()).get_valeur();
        
        boolean b = ((BoolV)cf.get_value()).getBoolV();
        
        cf.set_value(x);
        cf.get_stack().addFirst(new Cod(cf.get_code()));
        
        
        cf.set_code(b ? new LinkedList<>(cd1) : new LinkedList<>(cd2));
       
    }
    
}
