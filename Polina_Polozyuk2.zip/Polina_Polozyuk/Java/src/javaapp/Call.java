package javaapp;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.LinkedList;
/**
 *
 * @author ppolozyu
 */
public class Call extends Instr{
    private final String namef;
    
    public Call(String functionName){
        this.namef = functionName;
    }

    @Override
    void exec_instr(Config cf) {
        cf.get_code().pop();
        for(Pair<String, LinkedList<Instr>> pair : cf.get_env()){
            if(namef.equals(pair.get_first())){ 
                LinkedList<Instr> function_prog = new LinkedList<>(pair.get_second());
                function_prog.addAll(cf.get_code());               
                cf.set_code(function_prog);
                break;
            }
        }     
    }   
}
