/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp;
import java.util.LinkedList;
/**
 *
 * @author ppolozyu
 */
public class RmDefs extends Instr{
    private final int n;
    
    public RmDefs(int n){
        this.n = n;
    }

    @Override
    void exec_instr(Config cf) {
        LinkedList<Pair<String, LinkedList<Instr>>> env = cf.get_env();
        
        
        for(int i=0; i<n ; i++){
            env.pop();
        }
        
        cf.set_env(env);
        cf.get_code().pop();
    }
}

